# GeoINT R5 — GitHub Codespaces

Este árbol está preparado para abrirse directamente como Codespace.

## Qué hace automáticamente

Al crear el Codespace, `.devcontainer/post-create.sh` instala GDAL, crea `geoint-platform/.venv`, instala el lock de Python, instala los extras `dev`, genera un `JWT_SECRET` de desarrollo si no existe `.env`, ejecuta `npm ci` y construye `geoint-web/dist`.

El workflow `.github/workflows/geoint-r5-ci.yml` hace además, en GitHub Actions, un build limpio, arranca PostgreSQL/Redis/NATS/MinIO, ejecuta migraciones, pytest y el E2E de topografía y publica el `dist` como artifact. Si existen `NETLIFY_AUTH_TOKEN` y `NETLIFY_SITE_ID`, publica producción; si no, crea un deploy temporal anónimo para revisión.

## Recomendación de uso

Para Codespaces conviene subir **el contenido descomprimido de este repositorio**, no el ZIP de aplicación como único archivo. GitHub Codespaces crea el contenedor a partir de `.devcontainer/devcontainer.json`; el `postCreateCommand` es el mecanismo oficial para automatizar la preparación. GitHub documenta también el reenvío de puertos para abrir la aplicación en el navegador. 

Puertos principales: `5173` frontend, `8000` API, `9001` consola MinIO.

## Netlify

El workflow no necesita secretos para crear un deploy temporal de revisión porque Netlify CLI soporta `--allow-anonymous`; ese sitio temporal expira después de una hora si no se reclama. Para un sitio persistente, configura `NETLIFY_AUTH_TOKEN` y `NETLIFY_SITE_ID` como secrets del repositorio.
