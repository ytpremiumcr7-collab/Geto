#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"

PY_ROOT="$ROOT/geoint-platform"
WEB_ROOT="$ROOT/geoint-web"

if [[ ! -f "$PY_ROOT/requirements.lock.txt" || ! -f "$WEB_ROOT/package-lock.json" ]]; then
  echo "GeoINT source tree incompleto" >&2
  exit 1
fi

cd "$PY_ROOT"
python3 -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip setuptools wheel
python -m pip install -r requirements.lock.txt
python -m pip install -e ".[dev]"

if [[ ! -f .env ]]; then
  cp .env.example .env
  JWT_SECRET="$(openssl rand -hex 32)"
  sed -i "s/^JWT_SECRET=.*/JWT_SECRET=${JWT_SECRET}/" .env
fi

cd "$WEB_ROOT"
npm ci
npm run build

echo "Python venv + backend deps + frontend deps/build: OK"
