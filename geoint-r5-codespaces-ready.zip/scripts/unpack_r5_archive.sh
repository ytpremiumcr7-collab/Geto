#!/usr/bin/env bash
set -euo pipefail

ARCHIVE="${1:-geoint-fullstack-R5-REPRODUCIBLE-AUDITED.zip}"
DEST="${2:-.r5-extracted}"

rm -rf "$DEST"
mkdir -p "$DEST"

python3 - "$ARCHIVE" "$DEST" <<'PY'
from pathlib import Path
import sys, zipfile

archive = Path(sys.argv[1]).resolve()
dest = Path(sys.argv[2]).resolve()
with zipfile.ZipFile(archive) as z:
    for info in z.infolist():
        target = (dest / info.filename).resolve()
        if target != dest and dest not in target.parents:
            raise SystemExit(f"unsafe archive path: {info.filename}")
    z.extractall(dest)
print(f"Extracted {archive} -> {dest}")
PY
