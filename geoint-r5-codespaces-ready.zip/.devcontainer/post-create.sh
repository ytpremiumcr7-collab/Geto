#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"

sudo apt-get update
sudo apt-get install -y --no-install-recommends gdal-bin libgdal-dev python3-gdal unzip
rm -rf /var/lib/apt/lists/*

bash scripts/codespace_bootstrap.sh

echo
printf '%s\n' 'GeoINT Codespace preparado.'
printf '%s\n' 'Frontend: cd geoint-web && npm run dev -- --host 0.0.0.0'
printf '%s\n' 'Backend:  cd geoint-platform && source .venv/bin/activate && uvicorn app.main:app --host 0.0.0.0 --port 8000'
printf '%s\n' 'Stack:    cd geoint-platform && docker compose up -d'
